<?php
function getValue($inputValue)
{
    $array = [
        "skrydzio numeris"=>[
            0 => "A6",
            1 => "A8",
            2 => "B4"
        ],

        "is kur skrenda"=>[
            0=> "Vilnius",
            1 => "Kaunas",
            2 => "Šiauliai"
        ],
        
        "i kur skrenda"=>[
            0=> "Lisabona",
            1 => "Stanbulas",
            2 => "Pekinas"
        ]

        ];

    foreach($array[$inputValue] as $value)
    {
        echo '<option value ='.$value.'>'.$value.'</option>';
    }

};